//
//  setting.swift
//  BreakOut
//
//  Created by karthick mohanasundaram on 22/03/2017.
//  Copyright © 2017 karthick mohanasundaram. All rights reserved.
//

import UIKit
class setting: UIViewController {
    
   
    static var row = 4
    static var speed = 0.4
    static var size = 22
    
    @IBOutlet weak var outRow: UITextField!
    
    
    @IBAction func okButton(_ sender: UIButton) {
        setting.row = Int(outRow.text!)!
        outRow.resignFirstResponder()
        
    }
    
    @IBAction func speedSLOW(_ sender: UIButton) {
        
        switch setting.size {
            
        case 18:
        
            setting.speed = 0.2
            
        case 22:
            setting.speed = 0.3
            
        case 26:
            setting.speed = 0.4
        
        default:
            break
        }
        
    }
    
    
    @IBAction func speedMedium(_ sender: UIButton) {
        
        switch setting.size {
            
        case 18:
            
            setting.speed = 0.3
            
        case 22:
            setting.speed = 0.4
            
        case 26:
            setting.speed = 0.6
            
        default:
            break
        }
        
    }
    
    
    
    @IBAction func speedHIGH(_ sender: UIButton) {
        
        
        //setting.speed = 0.6
        
        switch setting.size {
            
        case 18:
            
            setting.speed = 0.4
            
        case 22:
            setting.speed = 0.6
            
        case 26:
            setting.speed = 0.8
            
        default:
            //setting.speed = 0.5
            break
        }
        
        
    }
    
    
    @IBAction func sizeSmall(_ sender: UIButton) {
        setting.size = 18
        setting.speed = 0.4
    }
   
    
    @IBAction func sizeBIG(_ sender: UIButton) {
        
        setting.size = 26
        setting.speed = 0.4
    }
    
    
    @IBAction func sizeMedium(_ sender: UIButton) {
        setting.size = 22
        setting.speed = 0.4
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //enableRandon.isOn
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
