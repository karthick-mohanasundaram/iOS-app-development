
//  BreakOutVC.swift
//  BreakOut


import UIKit

class BreakOutVC: UIViewController, breakout_protocol
{
    
    @IBOutlet weak var gamearea: UIView!
    var set = setting()
    var GameBehaviour = BreakOutBehaviour()
    
    lazy var gameDynamicAnimator: UIDynamicAnimator = {
        let BreakoutAnimator = UIDynamicAnimator(referenceView: self.gamearea)
        return BreakoutAnimator
    }()
    
    var ballView: UIView? = nil
    var paddleView: UIView? = nil
    var Ball_Size: CGSize { return CGSize(width: setting.size, height: setting.size) }
    let Ball_BorderColor = UIColor.red
    let paddle_BgColor = UIColor.black
    let paddle_BorderColor = UIColor.red
    var Brick_Rows: Int { return setting.row  }
    var Brick_Columns: Int { return 4 }
    let Brick_BorderColor = UIColor.black
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        gameDynamicAnimator.addBehavior(GameBehaviour)
        begingame()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    //setting the pangesture to move paddle across the screen
    @IBAction func moveGamePaddle(_ panGesture: UIPanGestureRecognizer) {
        switch panGesture.state {
        case .began: fallthrough
        case .changed: fallthrough
        case .ended:
            let translation = panGesture.translation(in: gamearea)
            GameBehaviour.movepaddle(paddleView!, translation: translation)
            panGesture.setTranslation(CGPoint.zero, in: gamearea)
        default:
            break
        }
    }
    
    
    //setting the tapgesture to bounce the ball when a touch is made on the view
    @IBAction func pushBall(_ tapGesture: UITapGestureRecognizer) {
        switch tapGesture.state {
        case .ended:
            GameBehaviour.bounceBall(ballView!, angle: 1.80, magnitude:CGFloat(setting.speed))
        default:
            break
        }
    }
    
    
    //called to set up new game.
    func begingame() {
        
        //removes the bricks, balls & paddle each time the game begins
        for subview in gamearea.subviews {
            GameBehaviour.deleteSubviews(view: subview, temp: false)
        }
        
        //calls drawBorders function in BreakOutBehaviour swift file
        GameBehaviour.drawBorders(gamearea)
        
        
        //draws a ball subview in parent view, places at specified coordinates
        let ballOrigin = CGPoint(x: gamearea.bounds.midX - 10,
                                   y: gamearea.bounds.maxY - CGFloat(40.0))
  
        ballView = UIView(frame: CGRect(origin: ballOrigin, size: Ball_Size))
        let Ball_BgColor = UIColor.RandomColor()
        ballView!.layer.backgroundColor = Ball_BgColor.cgColor
        ballView!.layer.borderColor = Ball_BorderColor.cgColor
        ballView!.layer.borderWidth = CGFloat(1.0)
        ballView!.layer.cornerRadius = Ball_Size.height / 2.0
        ballView!.type = game_things.ball
        GameBehaviour.addball(ballView!)
        
        
        let paddleOrigin = CGPoint(x: gamearea.bounds.midX - CGFloat(50.0),
                                   y: gamearea.bounds.maxY - CGFloat(15.0))
        //draws a paddle subview in parent view, places at specified coordinates
        paddleView = UIView(frame: CGRect(origin: paddleOrigin, size: CGSize(width: 100.0, height: 10.0)))
        paddleView!.layer.backgroundColor = paddle_BgColor.cgColor
        paddleView!.layer.borderColor = paddle_BorderColor.cgColor
        paddleView!.layer.borderWidth = CGFloat(1.0)
        paddleView!.type = game_things.paddle
        GameBehaviour.addpaddle(paddleView!)
        
        
        let brickWidth = CGFloat(75.0)
        let brickHeight = CGFloat(25.0)
        //draws no. of bricks; total of Brick_Rows + Brick_Columns
        for row in 0 ..< Brick_Rows {
            
            for column in 0 ..< Brick_Columns {
                
                //15.0 is the distance between each brick
                
                //50.0 is the distance between from the top of the window to the first line of bricks.
                
                //calculating the origin position of the bricks for each iteration
                let brickViewOrigin = CGPoint(x: CGFloat(15.0) + (brickWidth + CGFloat(15.0)) * CGFloat(column),y: CGFloat(50.0) + (brickHeight + CGFloat(10.0)) * CGFloat(row))
                
                //draws a brick at specified coordinates and size
                let brickView = UIView(frame: CGRect(origin: brickViewOrigin, size: (CGSize(width: brickWidth,height: brickHeight))))
                let Brick_BgColor = UIColor.RandomColor()
                brickView.layer.backgroundColor = Brick_BgColor.cgColor
                brickView.layer.borderColor = Brick_BorderColor.cgColor
                brickView.layer.borderWidth = CGFloat(1.0)
                brickView.layer.cornerRadius = CGFloat(2)
                brickView.type = game_things.brick
                
                
                GameBehaviour.game_protocol = self
                //calls addBrick func in BreakOutBehaviour file to apply dynamic animatore and collider behavior to each bricks
                GameBehaviour.addBrick(brickView)
            }
            
        }
    }
    
    //an alert window appears when there is no bricks to hit
    func win() {
        let activity1 = UIAlertController(title: "Congratulations", message: "YOU WON!", preferredStyle: UIAlertControllerStyle.alert)
        let newGameAction = UIAlertAction(title: "Play Again", style: UIAlertActionStyle.cancel) {
            (action: UIAlertAction!) -> Void in
            self.begingame()
        }
        activity1.addAction(newGameAction)
        
        present(activity1, animated: true, completion: nil)
    }
    
    //an alert window appears when ball hit the bottom
    func end() {
        let activity2 = UIAlertController(title: "LOST", message: "Ball hit the bottom of the view!", preferredStyle: UIAlertControllerStyle.alert)
        let newGameAction = UIAlertAction(title: "Try Again", style: UIAlertActionStyle.cancel) {
            (action: UIAlertAction!) -> Void in
            self.begingame()
        }
        activity2.addAction(newGameAction)
        present(activity2, animated: true, completion: nil)
    }
    
    }

    extension UIColor {
        static func  RandomColor() -> UIColor {
            let randomHue = CGFloat(arc4random()) / CGFloat(RAND_MAX)
            return UIColor(hue: randomHue, saturation: 1.0, brightness: 1.0, alpha: 0.5)
        }
    }

    
    
