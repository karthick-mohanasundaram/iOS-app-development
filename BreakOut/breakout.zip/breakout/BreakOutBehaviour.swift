
//  BreakOutBehaviour.swift
//  BreakOut

import UIKit
import AudioToolbox


class BreakOutBehaviour: UIDynamicBehavior, UICollisionBehaviorDelegate {
 
    // Sound Properties (as GLOBAL VARIABLES)
    var soundURL: NSURL?
    var soundID:SystemSoundID = 0
    
    //setting up the properties of collision behavior to engage ball, paddle and bricks in collision with oneanother
    lazy var collider: UICollisionBehavior = {
        let collider = UICollisionBehavior()
        collider.translatesReferenceBoundsIntoBoundary = true
        collider.collisionMode = UICollisionBehaviorMode.everything
        collider.collisionDelegate = self
        return collider
    }()
    
    //setting up the properties of dynamic behavior of ball
    lazy var ball_behavior: UIDynamicItemBehavior = {
        let ball_behavior = UIDynamicItemBehavior()
        ball_behavior.allowsRotation = false
        ball_behavior.elasticity = 1.0
        ball_behavior.friction = 0.0
        ball_behavior.resistance = 0.0
        return ball_behavior
    }()
    
    //setting up the properties of dynamic behavior of paddle
    lazy var paddle_behavior: UIDynamicItemBehavior = {
        let paddle_behavior = UIDynamicItemBehavior()
        paddle_behavior.allowsRotation = false
        paddle_behavior.elasticity = 1.0
        return paddle_behavior
    }()
    
    //setting up the properties of dynamic behavior of bricks
    lazy private var brick_behavior: UIDynamicItemBehavior = {
        let brick_behavior = UIDynamicItemBehavior()
        brick_behavior.allowsRotation = false
        return brick_behavior
    }()
 
    
    
  //adds the dynamic behavior items; ball, paddle and brick, as a child.
    override init() {
        super.init()
        addChildBehavior(collider)
        addChildBehavior(ball_behavior)
        addChildBehavior(paddle_behavior)
        addChildBehavior(brick_behavior)
    }
    
    
    //set dynamic animator and collision behavior to ball
    func addball(_ ball: UIView){
        
        dynamicAnimator?.referenceView?.addSubview(ball)
        //enables ball to engage collision with others
        collider.addItem(ball)
        
        ball_behavior.addItem(ball)
    }
    
    
    //set dynamic animator and collision behavior to paddle
    var paddle_attachment_behavior: UIAttachmentBehavior? = nil
    func addpaddle(_ paddle: UIView)
    {
        dynamicAnimator?.referenceView?.addSubview(paddle)
        collider.addItem(paddle)
        
        //sets the paddle anchor point at center
        paddle_attachment_behavior = UIAttachmentBehavior(item: paddle, attachedToAnchor: paddle.center)
        
        addChildBehavior(paddle_attachment_behavior!)
        paddle_behavior.addItem(paddle)
    }
    
    
    //set dynamic animator and collision behavior to the array of bricks
    var brick_attachment_behaviour: [UIView: UIAttachmentBehavior] = [:]
    func addBrick(_ brick: UIView)
    {
        dynamicAnimator?.referenceView?.addSubview(brick)
        //enables bricks to engage collision with others
        collider.addItem(brick)
        
        //sets the bricks anchor point at center
        brick_attachment_behaviour[brick] = UIAttachmentBehavior(item: brick, attachedToAnchor: brick.center)
        
        //applies dynamic animatore to bricks
        addChildBehavior(brick_attachment_behaviour[brick]!)
        brick_behavior.addItem(brick)
    }
    
    
    //set collision behaviour to boundary; top, left and right
    func drawBorders(_ view: UIView) {

        let topLeft = CGPoint(x: view.frame.minX, y: view.frame.maxY)
        let topRight = CGPoint(x: view.frame.maxX, y: view.frame.maxY)
        
        collider.addBoundary(withIdentifier: "Bottom" as NSCopying, from: topLeft, to: topRight)

    }
    
    //updates the new anchor point of paddle with respect to pan gesture
    func movepaddle(_ view: UIView, translation: CGPoint) {
        view.center.x += translation.x
        paddle_attachment_behavior?.anchorPoint.x = view.center.x
        dynamicAnimator?.updateItem(usingCurrentState: view)
    }
    
    //applies push behavior to ball to change travelling path accordingly when collides with paddle and bricks
    func bounceBall(_ view: UIView, angle: CGFloat, magnitude: CGFloat) {
        
        let ball_bounce = UIPushBehavior(items: [view], mode: UIPushBehaviorMode.instantaneous)
        ball_bounce.angle = angle
        ball_bounce.magnitude = magnitude
        ball_bounce.action = {
            ball_bounce.dynamicAnimator?.removeBehavior(ball_bounce)
        }
        dynamicAnimator?.addBehavior(ball_bounce)
    }
    
    
    
    //deletes only hit bricks or all subviews from the view based on the value of animated
    func deleteSubviews(view: UIView, temp: Bool = true) {
        
        //add transition befor bricks is removed when ball hits over it
        if temp == true {
            
            //sound
            play(sound: "bone")
            
            UIView.transition(with: view, duration: 0.5,
                              options: .transitionFlipFromTop,
                              animations: { },
                              completion: { (finished: Bool) -> Void in
                                self.deleteSubviews(view: view, temp: false)
            })
            return
        }
        
        
        //remove ball, bricks, and paddle before the new game begins
        switch view.type {
        case .ball:
            ball_behavior.removeItem(view)
        case .paddle:
                paddle_behavior.removeItem(view)
        case .brick:
            if brick_attachment_behaviour[view] != nil {
                brick_behavior.removeItem(view)
                removeChildBehavior(brick_attachment_behaviour[view]!)
                brick_attachment_behaviour[view] = nil
            } else { return }
        default:
            return
        }
        collider.removeItem(view)
        view.removeFromSuperview()
    }
    
    
    
    
    var game_protocol: breakout_protocol? = nil
    
    //called when a collision is started between any two dynamic items.
    func collisionBehavior(_ behavior: UICollisionBehavior, beganContactFor item1: UIDynamicItem, with item2: UIDynamicItem, at p: CGPoint) {
        let (ballView, brickView) = collidedItems([item1, item2])

        if brickView != nil {
            
            //game ends when ball hits final brick
            if brick_attachment_behaviour.count == 1 {
                
                //plays winning sound
                play(sound: "cheer")
                
                //called to begin new game
                game_protocol?.win()
                
                //disabling the collision behaviour of ball
                collider.removeItem(ballView!)
                ballView?.removeFromSuperview()
            }
            deleteSubviews(view: brickView!, temp: true)
        }
    }
    
    
    //Called when a collision is started between ball and boundary.
    func collisionBehavior(_ behavior: UICollisionBehavior, beganContactFor item: UIDynamicItem, withBoundaryIdentifier identifier: NSCopying?, at p: CGPoint) {
        let (ballView, _) = collidedItems([item])
        if let borderID = identifier as? String {
            
            switch borderID {
                
            //test whether the ball hits the bottom boundary
            case "Bottom":
                    //plays losing sound
                    if brick_attachment_behaviour.count != 0
                    {
                    play(sound: "endbuzzer")
                    }
                    //game ends
                    game_protocol?.end()
                    collider.removeItem(ballView!)
                    ballView?.removeFromSuperview()
            default:
                break
            }
        }
    }
            
    
    //called when collision occurs to identify the collided items
    func collidedItems(_ items: [UIDynamicItem]) -> (ballView: UIView?, brickView: UIView?) {
        
        var ballView: UIView? = nil
        var brickView: UIView? = nil
        for item in items {
            if let view = item as? UIView {
                switch view.type {
                case .ball:
                    ballView = view
                case .brick:
                    brickView = view
                default:
                    break
                }
            }
        }
        return (ballView, brickView)
    }
    
    
    func play(sound: String){
        let filename = sound
        let ext = "mp3"
        
        //plays the sound is executed only if the sound file exists and and accessible to the application
        if let soundUrl = Bundle.main.url(forResource: filename, withExtension: ext) {
            
            //Sound ID for the song we want to play
            var soundId: SystemSoundID = 0
            AudioServicesCreateSystemSoundID(soundUrl as CFURL, &soundId)
            
            
            //After playing sound, sound ID is dispose by callback function
            AudioServicesAddSystemSoundCompletion(soundId, nil, nil, { (soundId, clientData) -> Void in
                
                AudioServicesDisposeSystemSoundID(soundId)
            }, nil)
            
            //plays sound
            AudioServicesPlaySystemSound(soundId)
        }
    }
}

public enum game_things: Int {
    case ball = 1
    case paddle
    case brick
    case border
}

public extension UIView {
    var type: game_things {
        get {
            return game_things(rawValue: self.tag)!
        }
        set {
            self.tag = newValue.rawValue
        }
    }
}
public protocol breakout_protocol {
    func win() -> Void
    func end() -> Void
}


    
